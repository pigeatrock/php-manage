<?php
namespace App\http\Controllers;
use App\Http\Controllers\Controller;
use App\User;

class UserController extends Controller{
    public function index()
    {
        echo 1;exit();
    }
    public function index2()
    {
        echo 2;exit();
    }
}
?>