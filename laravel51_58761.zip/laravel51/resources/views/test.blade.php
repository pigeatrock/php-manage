<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>


        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="content">
                <div><?php echo 2;?></div>
                <h2>@{{ esdf }}</h2>
                <div class="title">hhhhhhhhLaravel 5</div>
                @if(1+1>3) <h2>gt 3</h2>
                @else
                    <h3>lt 3 </h3>
                @endif
            </div>
        </div>
        <script src="https://cdn.bootcss.com/vue/2.5.16/vue.min.js"></script>
        <script>

            new Vue({
                el:'.container',
                data:{
                    esdf:1222222
                }

            })
        </script>
    </body>
</html>
